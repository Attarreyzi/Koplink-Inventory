@extends('layouts.admin')

@section('title', 'Laporan Inventory')

@section('content')
<div class="card filter-form">
    <form action="{{ route('admin.reports.index') }}" method="GET">
        <div style="display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 1rem;">
            <div style="flex: 1; min-width: 200px;">
                <label style="display: block; margin-bottom: 5px; color: #94a3b8; font-size: 0.85rem; font-weight: 600; text-transform: uppercase;">Tanggal Mulai</label>
                <input type="date" name="start_date" id="start_date" class="form-control" value="{{ request('start_date') }}">
            </div>
            <div style="flex: 1; min-width: 200px;">
                <label style="display: block; margin-bottom: 5px; color: #94a3b8; font-size: 0.85rem; font-weight: 600; text-transform: uppercase;">Tanggal Selesai</label>
                <input type="date" name="end_date" id="end_date" class="form-control" value="{{ request('end_date') }}">
            </div>
        </div>
        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
            <button type="submit" class="btn" style="flex: 1; min-width: 150px;">TAMPILKAN</button>
            <button type="button" onclick="downloadPDF()" class="btn" style="flex: 1; min-width: 150px; background-color: var(--success); color: white; border: none;">CETAK LAPORAN (PDF)</button>
        </div>
    </form>
</div>

<div id="report-to-print">
    <!-- Halaman Utama (Tampilan di Web - Tetap Dark Mode) -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
        <div class="card" style="margin-bottom: 0;">
            <div style="color: #94a3b8; font-size: 0.9rem; text-transform: uppercase;">Total Omset</div>
            <div style="font-size: 1.8rem; font-weight: 800; color: var(--text-color);">
                Rp {{ number_format($totalRevenue, 0, ',', '.') }}
            </div>
        </div>
        <div class="card" style="margin-bottom: 0;">
            <div style="color: #10b981; font-size: 0.9rem; text-transform: uppercase;">Total Keuntungan</div>
            <div style="font-size: 1.8rem; font-weight: 800; color: #10b981;">
                Rp {{ number_format($totalProfit, 0, ',', '.') }}
            </div>
        </div>
        <div class="card" style="margin-bottom: 0;">
            <div style="color: #94a3b8; font-size: 0.9rem; text-transform: uppercase;">Stok Terjual</div>
            <div style="font-size: 1.8rem; font-weight: 800; color: var(--primary-accent);">
                {{ $stockOutCount }} Item
            </div>
        </div>
    </div>

    <div class="card">
        <h2 style="margin-top: 0;">Daftar Transaksi Penjualan</h2>
        <table>
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Waktu</th>
                    <th>Jumlah</th>
                    <th>Harga Satuan</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                @forelse($transactions->where('type', 'out') as $t)
                <tr>
                    <td data-label="Produk">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            @if($t->product && $t->product->image)
                                <img src="{{ str_starts_with($t->product->image, 'products/') ? url('/img-view/' . $t->product->image) : asset($t->product->image) }}" alt="" style="width: 35px; height: 35px; object-fit: cover; border-radius: 6px; border: 1px solid rgba(255,255,255,0.1);">
                            @else
                                <div style="width: 35px; height: 35px; background: #222; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 0.5rem; color: #555;">No Img</div>
                            @endif
                            <strong>{{ $t->product->name ?? 'Produk' }}</strong>
                        </div>
                    </td>
                    <td data-label="Waktu"><div class="val-wrap"><span>{{ $t->created_at->format('d/m/Y H:i') }}</span></div></td>
                    <td data-label="Jumlah"><div class="val-wrap"><span>{{ $t->quantity }}</span></div></td>
                    <td data-label="Harga Satuan"><div class="val-wrap"><span>Rp {{ number_format($t->product->price ?? 0, 0, ',', '.') }}</span></div></td>
                    <td data-label="Total">
                        <div class="val-wrap">
                            <strong style="font-size: 1.1rem; color: var(--text-color);">Rp {{ number_format(($t->product->price ?? 0) * $t->quantity, 0, ',', '.') }}</strong>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="5" style="text-align: center; color: var(--secondary-accent); padding: 2rem 0;">Tidak ada data penjualan untuk periode ini.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<!-- Template Khusus PDF (Hidden, White Theme) -->
<div id="pdf-template" style="display: none;">
    <div style="padding: 20px; color: black; background: white; font-family: Arial, sans-serif;">
        <div style="text-align: center; border-bottom: 2px solid black; padding-bottom: 10px; margin-bottom: 20px;">
            <h1 style="margin: 0; font-size: 24px;">LAPORAN DATA PENJUALAN</h1>
            <h2 style="margin: 5px 0; font-size: 18px;">KOPLINK</h2>
            <p style="margin: 0;">Periode: {{ request('start_date') ? date('d/m/Y', strtotime(request('start_date'))) : '-' }} s/d {{ request('end_date') ? date('d/m/Y', strtotime(request('end_date'))) : '-' }}</p>
        </div>

        <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
            <div style="border: 1px solid #ddd; padding: 10px; flex: 1; margin-right: 10px; text-align: center;">
                <p style="margin: 0; font-size: 12px; color: #666;">TOTAL OMSET</p>
                <p style="margin: 5px 0; font-size: 18px; font-weight: bold;">Rp {{ number_format($totalRevenue, 0, ',', '.') }}</p>
            </div>
            <div style="border: 1px solid #ddd; padding: 10px; flex: 1; margin-right: 10px; text-align: center;">
                <p style="margin: 0; font-size: 12px; color: #666;">TOTAL KEUNTUNGAN</p>
                <p style="margin: 5px 0; font-size: 18px; font-weight: bold; color: green;">Rp {{ number_format($totalProfit, 0, ',', '.') }}</p>
            </div>
            <div style="border: 1px solid #ddd; padding: 10px; flex: 1; text-align: center;">
                <p style="margin: 0; font-size: 12px; color: #666;">ITEM TERJUAL</p>
                <p style="margin: 5px 0; font-size: 18px; font-weight: bold;">{{ $stockOutCount }}</p>
            </div>
        </div>

        <h3 style="border-bottom: 1px solid #eee; padding-bottom: 5px;">Detail Penjualan</h3>
        <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
            <thead>
                <tr style="background: #f8f9fa;">
                    <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Waktu</th>
                    <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Produk</th>
                    <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Qty</th>
                    <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Harga</th>
                    <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach($transactions->where('type', 'out') as $t)
                <tr>
                    <td style="border: 1px solid #ddd; padding: 8px;">{{ $t->created_at->format('d/m/Y H:i') }}</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">
                        <div style="display: flex; align-items: center; gap: 5px;">
                            @if($t->product && $t->product->image)
                                <img src="{{ str_starts_with($t->product->image, 'products/') ? url('/img-view/' . $t->product->image) : asset($t->product->image) }}" alt="" style="width: 25px; height: 25px; object-fit: cover; border-radius: 4px;">
                            @endif
                            <span>{{ $t->product->name ?? '-' }}</span>
                        </div>
                    </td>
                    <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">{{ $t->quantity }}</td>
                    <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">Rp {{ number_format($t->product->price ?? 0, 0, ',', '.') }}</td>
                    <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">Rp {{ number_format(($t->product->price ?? 0) * $t->quantity, 0, ',', '.') }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <div style="margin-top: 30px; text-align: right; font-size: 12px;">
            <p>Dicetak pada: {{ date('d/m/Y H:i') }}</p>
            <br><br>
            <p>( ____________________ )</p>
            <p>Admin Koplink</p>
        </div>
    </div>
</div>

<script>
    function showWarningToast(message) {
        let toast = document.getElementById('warning-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'warning-toast';
            toast.style.position = 'fixed';
            toast.style.bottom = '20px';
            toast.style.right = '20px';
            toast.style.backgroundColor = '#ef4444';
            toast.style.color = '#ffffff';
            toast.style.padding = '12px 24px';
            toast.style.borderRadius = '8px';
            toast.style.boxShadow = '0 10px 15px -3px rgba(0, 0, 0, 0.5), 0 4px 6px -2px rgba(0, 0, 0, 0.5)';
            toast.style.zIndex = '9999';
            toast.style.fontFamily = "'Outfit', sans-serif";
            toast.style.fontWeight = '600';
            toast.style.fontSize = '0.9rem';
            toast.style.transition = 'all 0.3s ease';
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(20px)';
            document.body.appendChild(toast);
        }
        
        toast.innerText = message;
        
        // Show the toast
        setTimeout(() => {
            toast.style.opacity = '1';
            toast.style.transform = 'translateY(0)';
        }, 10);
        
        // Hide the toast after 3 seconds
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(20px)';
        }, 3000);
    }

    function downloadPDF() {
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;

        if (!startDate || !endDate) {
            showWarningToast('Silakan isi Tanggal Mulai dan Tanggal Selesai terlebih dahulu!');
            return;
        }

        // Check if url query params match current input values
        const urlParams = new URLSearchParams(window.location.search);
        const queryStart = urlParams.get('start_date');
        const queryEnd = urlParams.get('end_date');

        if (startDate !== queryStart || endDate !== queryEnd) {
            showWarningToast('Silakan klik TAMPILKAN terlebih dahulu untuk memperbarui data laporan!');
            return;
        }

        const element = document.getElementById('pdf-template');
        element.style.display = 'block'; // Tampilkan sementara untuk capture
        
        const opt = {
            margin:       10,
            filename:     `Laporan_Penjualan_Koplink_Periode_${startDate}_s_d_${endDate}.pdf`,
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2 },
            jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };

        html2pdf().set(opt).from(element).save().then(() => {
            element.style.display = 'none'; // Sembunyikan kembali
        });
    }
</script>
@endsection
