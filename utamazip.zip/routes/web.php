<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminProductController;
use App\Http\Controllers\StockController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

/* Fallback route for storage images (especially useful on Windows/XAMPP) */
/* New Safe Fallback route for images */
Route::get('/img-view/{path}', function ($path) {
    $fullPath = storage_path('app/public/' . $path);
    if (!file_exists($fullPath)) {
        abort(404);
    }
    return response()->file($fullPath);
})->where('path', '.*');


/* Authentication Routes */
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

/* Root Route */
Route::get('/', function() {
    return redirect()->route('login');
});

/* Admin Routes */
Route::prefix('admin')->name('admin.')->middleware('auth')->group(function() {
    Route::get('/', function () { return redirect()->route('admin.dashboard'); });
    Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::resource('products', AdminProductController::class);
    Route::resource('categories', CategoryController::class)->except(['edit', 'update']);
    Route::get('stock', [StockController::class, 'history'])->name('stock.history');
    Route::get('stock/{product}/{type}', [StockController::class, 'form'])->name('stock.form');
    Route::post('stock/{product}/{type}', [StockController::class, 'store'])->name('stock.store');
    Route::get('reports', [ReportController::class, 'index'])->name('reports.index');
});
