<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\StockTransaction;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $products = Product::all();
        $totalValuation = $products->sum(function ($product) {
            return $product->stock * $product->price;
        });

        $totalStock = $products->sum('stock');

        // Optional filtering by date
        $query = StockTransaction::query();
        if ($request->has('start_date') && $request->has('end_date') && $request->start_date && $request->end_date) {
            $query->whereBetween('created_at', [$request->start_date . ' 00:00:00', $request->end_date . ' 23:59:59']);
        }
        
        $transactions = $query->with('product')->latest()->get();

        $stockInCount = $transactions->where('type', 'in')->sum('quantity');
        $stockOutCount = $transactions->where('type', 'out')->sum('quantity');

        // Hitung Keuntungan (Hanya dari stok keluar)
        $totalProfit = $transactions->where('type', 'out')->sum(function ($transaction) {
            // Keuntungan per unit = Harga Jual - Harga Modal
            $profitPerUnit = $transaction->product->price - $transaction->product->purchase_price;
            return $profitPerUnit * $transaction->quantity;
        });

        // Hitung Total Omset (Hanya dari stok keluar)
        $totalRevenue = $transactions->where('type', 'out')->sum(function ($transaction) {
            return $transaction->product->price * $transaction->quantity;
        });

        return view('admin.reports.index', compact(
            'products', 
            'totalValuation', 
            'totalStock', 
            'stockInCount', 
            'stockOutCount',
            'transactions',
            'totalProfit',
            'totalRevenue'
        ));
    }
}
