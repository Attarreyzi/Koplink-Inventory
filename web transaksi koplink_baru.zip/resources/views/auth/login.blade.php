@extends('layouts.admin')
{{-- Kami menggunakan layout admin untuk CSS-nya, tapi tanpa sidebar --}}

@section('content')
<style>
    .sidebar, .header, .bottom-nav { display: none !important; }
    .content { padding: 0; display: flex; align-items: center; justify-content: center; min-height: 100vh; background: #000; position: relative; overflow: hidden; }
    .content::before {
        content: "";
        position: absolute;
        width: 150%;
        height: 150%;
        background: url('{{ asset('logo.jpg') }}') center center no-repeat;
        background-size: contain;
        opacity: 0.35;
        mix-blend-mode: screen;
        filter: grayscale(100%);
        transform: rotate(-15deg);
        pointer-events: none;
    }
    .login-card { background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(8px); padding: 3rem; border-radius: 20px; border: 1px solid rgba(255, 255, 255, 0.1); width: 90%; max-width: 400px; box-shadow: 0 20px 50px rgba(0,0,0,0.8); z-index: 1; }
    .form-group { margin-bottom: 1.8rem; }
    .form-group label { margin-bottom: 0.6rem; color: #cbd5e1; font-weight: 500; font-size: 0.9rem; }
    .form-control { background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: #fff; padding: 1rem; border-radius: 10px; }
    .form-control:focus { background: rgba(255, 255, 255, 0.1); border-color: #fff; color: #fff; }
    .brand { display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; margin-bottom: 2.5rem; }
    .brand h1 { color: #fff; margin: 0; font-size: 2.8rem; font-weight: 600; letter-spacing: -1px; text-transform: none; opacity: 1; }
    .brand p { color: #94a3b8; margin-top: 8px; font-size: 1rem; font-weight: 400; }
    .btn-login { width: 100%; background: #fff; color: #000; padding: 1rem; border-radius: 10px; font-weight: 800; border: none; cursor: pointer; transition: all 0.3s; margin-top: 0.5rem; letter-spacing: 1px; }
    .btn-login:hover { transform: translateY(-2px); opacity: 0.9; box-shadow: 0 10px 20px rgba(255,255,255,0.2); }
    .error-msg { color: #ef4444; font-size: 0.85rem; margin-top: 5px; }

    @media (max-width: 480px) {
        .login-card { padding: 2.5rem 1.5rem; width: 92%; }
        .brand h1 { font-size: 2.3rem; }
        .form-group { margin-bottom: 1.5rem; }
        .brand { margin-bottom: 2rem; }
    }
</style>

<div class="login-card">
    <div class="brand">
        <h1>Login</h1>
        <p>Silakan masuk untuk melanjutkan</p>
    </div>

    <form action="{{ url('/login') }}" method="POST">
        @csrf
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="{{ old('email') }}" required autofocus>
            @error('email') <div class="error-msg">{{ $message }}</div> @enderror
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <div class="form-group" style="display: flex; align-items: center; gap: 8px;">
            <input type="checkbox" name="remember" id="remember">
            <label for="remember" style="margin-bottom: 0; font-size: 0.85rem;">Ingat Saya</label>
        </div>

        <button type="submit" class="btn-login">MASUK</button>
    </form>
</div>
@endsection
