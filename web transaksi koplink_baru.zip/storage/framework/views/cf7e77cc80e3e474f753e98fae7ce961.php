<?php $__env->startSection('title', 'Tambah Produk'); ?>

<?php $__env->startSection('content'); ?>
<div style="margin-bottom: 1.5rem; display: flex; justify-content: flex-end;">
    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn" style="background:#333333; color:#ffffff; border:none;">Kembali</a>
</div>

<div class="card" style="max-width: 600px;">
    <form action="<?php echo e(route('admin.products.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Nama Produk</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label>Kategori</label>
            <select name="category_id" class="form-control" required>
                <option value="">Pilih Kategori</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Harga Modal (Beli)</label>
                <input type="number" name="purchase_price" class="form-control" required min="0" placeholder="Contoh: 10000">
            </div>
            <div class="form-group">
                <label>Harga Jual</label>
                <input type="number" name="price" class="form-control" required min="0" placeholder="Contoh: 15000">
            </div>
        </div>

        <div class="form-group">
            <label>Stok Awal</label>
            <input type="number" name="stock" class="form-control" value="0" required min="0">
        </div>

        <div class="form-group">
            <label>Foto Produk (Opsional)</label>
            <input type="file" name="image" class="form-control" accept="image/*">
        </div>

        <div class="form-group">
            <label>Deskripsi (Opsional)</label>
            <textarea name="description" class="form-control" rows="3"></textarea>
        </div>

        <button type="submit" class="btn">Simpan Produk</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamp\htdocs\web transaksi koplink\resources\views/admin/products/create.blade.php ENDPATH**/ ?>