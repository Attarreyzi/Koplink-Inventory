<?php $__env->startSection('title', 'Manajemen Produk'); ?>

<?php $__env->startSection('content'); ?>
<div style="margin-bottom: 1.5rem; display: flex; justify-content: flex-end;">
    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn">Tambah Produk</a>
</div>

<div class="card">
    <table>
        <thead>
            <tr>
                <th>Produk</th>
                <th>Kategori</th>
                <th>Harga Modal</th>
                <th>Harga Jual</th>
                <th>Stok</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td data-label="Produk">
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <?php if($p->image): ?>
                            <img src="<?php echo e(str_starts_with($p->image, 'products/') ? url('/img-view/' . $p->image) : asset($p->image)); ?>" alt="" style="width: 50px; height: 50px; object-fit: cover; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1);">
                        <?php else: ?>
                            <div style="width: 50px; height: 50px; background: #222; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 0.6rem; color: #555; border: 1px solid rgba(255,255,255,0.1);">No Img</div>
                        <?php endif; ?>
                        <div>
                            <strong><?php echo e($p->name); ?></strong><br>
                            <small style="color: var(--secondary-accent)"><?php echo e($p->description); ?></small>
                        </div>
                    </div>
                </td>
                <td data-label="Kategori"><div class="val-wrap"><span><?php echo e($p->category->name ?? '-'); ?></span></div></td>
                <td data-label="Harga Modal"><div class="val-wrap"><span>Rp <?php echo e(number_format($p->purchase_price, 0, ',', '.')); ?></span></div></td>
                <td data-label="Harga Jual"><div class="val-wrap"><span>Rp <?php echo e(number_format($p->price, 0, ',', '.')); ?></span></div></td>
                <td data-label="Stok" class="stok-cell">
                    <div class="stok-number val-wrap">
                        <span style="font-size: 1.2rem; font-weight: 800;"><?php echo e($p->stock); ?></span>
                    </div>
                    <div class="stok-buttons" style="display: flex; gap: 6px;">
                        <a href="<?php echo e(route('admin.stock.form', [$p->id, 'in'])); ?>" style="color:#ffffff; font-size:0.75rem; text-decoration:none; background:#333333; padding:4px 10px; border-radius:6px; font-weight:700; white-space:nowrap;">+ IN</a>
                        <a href="<?php echo e(route('admin.stock.form', [$p->id, 'out'])); ?>" style="color:#000000; font-size:0.75rem; text-decoration:none; background:#e5e5e5; padding:4px 10px; border-radius:6px; font-weight:700; white-space:nowrap;">- OUT</a>
                    </div>
                </td>
                <td data-label="Aksi">
                    <div class="val-wrap">
                        <a href="<?php echo e(route('admin.products.edit', $p->id)); ?>" class="btn btn-sm" style="background:transparent; border: 1px solid var(--border-color); color:var(--text-color); padding: 0.6rem 1rem;">Edit</a>
                        <form action="<?php echo e(route('admin.products.destroy', $p->id)); ?>" method="POST" class="delete-form" style="display: inline-block;">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" style="padding: 0.6rem 1rem;">Hapus</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" style="text-align: center; color: var(--secondary-accent); padding: 2rem 0;">Belum ada produk.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamp\htdocs\web transaksi koplink\resources\views/admin/products/index.blade.php ENDPATH**/ ?>