<?php $__env->startSection('title', 'Edit Produk'); ?>

<?php $__env->startSection('content'); ?>
<div style="margin-bottom: 1.5rem; display: flex; justify-content: flex-end;">
    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn" style="background:#333333; color:#ffffff; border:none;">Kembali</a>
</div>

<div class="card" style="max-width: 600px;">
    <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="form-group">
            <label>Nama Produk</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($product->name); ?>" required>
        </div>
        
        <div class="form-group">
            <label>Kategori</label>
            <select name="category_id" class="form-control" required>
                <option value="">Pilih Kategori</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e($product->category_id == $category->id ? 'selected' : ''); ?>>
                        <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        
        
        <div class="form-row">
            <div class="form-group">
                <label>Harga Modal (Beli)</label>
                <input type="number" name="purchase_price" class="form-control" value="<?php echo e($product->purchase_price); ?>" required min="0">
            </div>
            <div class="form-group">
                <label>Harga Jual</label>
                <input type="number" name="price" class="form-control" value="<?php echo e($product->price); ?>" required min="0">
            </div>
        </div>

        <?php if($product->image): ?>
        <div class="form-group">
            <label>Foto Saat Ini</label><br>
            <img src="<?php echo e(str_starts_with($product->image, 'products/') ? url('/img-view/' . $product->image) : asset($product->image)); ?>" alt="<?php echo e($product->name); ?>" style="max-width: 150px; border-radius: 8px; margin-bottom: 10px; border: 1px solid rgba(255,255,255,0.1)">
        </div>
        <?php endif; ?>

        <div class="form-group">
            <label>Ganti Foto (Opsional)</label>
            <input type="file" name="image" class="form-control" accept="image/*">
        </div>

        <div class="form-group">
            <label>Deskripsi (Opsional)</label>
            <textarea name="description" class="form-control" rows="3"><?php echo e($product->description); ?></textarea>
        </div>

        <div style="color: #94a3b8; font-size: 0.9rem; margin-bottom: 20px;">
            * Stok tidak dapat diubah dari sini. Silakan gunakan fitur Stok Masuk / Keluar.
        </div>

        <button type="submit" class="btn">Update Produk</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamp\htdocs\web transaksi koplink\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>