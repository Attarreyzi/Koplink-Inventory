<?php $__env->startSection('title', 'Dashboard Inventory'); ?>

<?php $__env->startSection('content'); ?>
<div class="stat-grid">
    <div class="card" style="margin-bottom: 0;">
        <h3 style="margin-top: 0; color: var(--secondary-accent); font-size: 0.9rem; text-transform: uppercase;">Total Produk</h3>
        <p style="font-size: 2.5rem; font-weight: 800; margin: 0.5rem 0 0 0;"><?php echo e($totalProducts); ?></p>
    </div>
    <div class="card" style="margin-bottom: 0;">
        <h3 style="margin-top: 0; color: var(--secondary-accent); font-size: 0.9rem; text-transform: uppercase;">Total Stok</h3>
        <p style="font-size: 2.5rem; font-weight: 800; margin: 0.5rem 0 0 0;"><?php echo e($totalStock); ?></p>
    </div>
    <div class="card" style="margin-bottom: 0; border-color: var(--danger);">
        <h3 style="margin-top: 0; color: var(--danger); font-size: 0.9rem; text-transform: uppercase;">Stok Menipis</h3>
        <p style="font-size: 2.5rem; font-weight: 800; margin: 0.5rem 0 0 0; color: var(--danger);"><?php echo e($lowStockItems->count()); ?></p>
    </div>
</div>

<div class="dashboard-grid">
    <div class="card">
        <h2 style="margin-top: 0; font-size: 1.25rem;">Stok Menipis (Di Bawah 10)</h2>
        <?php if($lowStockItems->count() > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Kategori</th>
                        <th>Stok Tersisa</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $lowStockItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="Produk"><strong><?php echo e($item->name); ?></strong></td>
                            <td data-label="Kategori"><?php echo e($item->category->name ?? '-'); ?></td>
                            <td data-label="Stok Tersisa">
                                <div class="val-wrap">
                                    <span style="color: var(--danger); font-weight: 800;"><?php echo e($item->stock); ?></span>
                                </div>
                            </td>
                            <td data-label="Aksi">
                                <div class="val-wrap" style="grid-template-columns: 1fr;">
                                    <a href="<?php echo e(route('admin.stock.form', [$item->id, 'in'])); ?>" class="btn btn-sm" style="padding: 0.6rem 1.25rem;">Restock</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="color: var(--secondary-accent);">Semua stok produk saat ini aman.</p>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2 style="margin-top: 0; font-size: 1.25rem;">Transaksi Terakhir</h2>
        <?php if($recentTransactions->count() > 0): ?>
            <div style="display: flex; flex-direction: column; gap: 1rem;">
                <?php $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.5rem;">
                            <strong style="display: block;"><?php echo e($tx->product->name ?? 'Produk Terhapus'); ?></strong>
                            <span style="font-weight: 800; color: <?php echo e($tx->type == 'in' ? 'var(--text-color)' : '#a3a3a3'); ?>">
                                <?php echo e($tx->type == 'in' ? '+' : '-'); ?><?php echo e($tx->quantity); ?>

                            </span>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-size: 0.8rem; color: var(--secondary-accent);">
                            <span><?php echo e($tx->type == 'in' ? 'Barang Masuk' : 'Barang Keluar'); ?></span>
                            <span><?php echo e($tx->created_at->diffForHumans()); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a href="<?php echo e(route('admin.stock.history')); ?>" style="display: block; text-align: center; margin-top: 1rem; color: var(--text-color); font-size: 0.85rem;">Lihat Semua Transaksi</a>
        <?php else: ?>
            <p style="color: var(--secondary-accent);">Belum ada histori pergerakan stok.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamp\htdocs\web transaksi koplink\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>