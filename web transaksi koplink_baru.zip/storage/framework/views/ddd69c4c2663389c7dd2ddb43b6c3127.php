<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Koplink</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #000000;
            --text-color: #ffffff;
            --primary-accent: #ffffff;
            --secondary-accent: #a3a3a3;
            --card-bg: #111111;
            --sidebar-bg: #0a0a0a;
            --border-color: #262626;
            --danger: #ef4444;
            --success: #10b981;
            --warning: #f59e0b;
        }

        body {
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-color);
            color: var(--text-color);
            margin: 0;
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            box-sizing: border-box;
            width: 250px;
            background: var(--sidebar-bg);
            border-right: 1px solid var(--border-color);
            padding: 2rem 1rem;
            display: flex;
            flex-direction: column;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }

        /* Collapsed Sidebar Styles */
        .sidebar.collapsed {
            width: 80px;
            padding: 2rem 0.5rem;
        }

        .sidebar.collapsed h2, 
        .sidebar.collapsed span, 
        .sidebar.collapsed a span,
        .sidebar.collapsed button span {
            display: none;
        }

        .sidebar.collapsed .sidebar-item {
            justify-content: center;
            text-align: center;
            padding: 1rem 0;
        }

        .sidebar h2 {
            margin: 0 0 2rem 1rem;
            color: var(--primary-accent);
            font-size: 1.5rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .sidebar a {
            color: #a3a3a3;
            text-decoration: none;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .sidebar a:hover, .sidebar a.active {
            background: rgba(255, 255, 255, 0.05);
            color: var(--primary-accent);
        }



        @keyframes fadeSlideUp {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .content {
            flex: 1;
            padding: 2rem 3rem;
            overflow-y: auto;
            transition: all 0.3s ease;
            animation: fadeSlideUp 0.6s ease forwards;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 1rem;
        }

        .header h1 {
            margin: 0;
            font-size: 2rem;
            font-weight: 800;
            letter-spacing: -0.5px;
        }

        .card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 1.5rem;
            border: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .btn {
            display: inline-block;
            background: var(--primary-accent);
            color: #000000;
            padding: 0.6rem 1.2rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 700;
            border: none;
            cursor: pointer;
            transition: transform 0.2s, opacity 0.3s;
        }

        .btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }

        .btn-sm {
            padding: 0.4rem 0.8rem;
            font-size: 0.85rem;
        }

        .btn-danger { background: transparent; border: 1px solid var(--border-color); color: var(--danger); box-sizing: border-box;}
        .btn-danger:hover { background: rgba(255, 255, 255, 0.05); color: var(--danger); border-color: var(--border-color); }
        .btn-success { background: var(--card-bg); border: 1px solid var(--border-color); color: var(--success); box-sizing: border-box;}
        .btn-success:hover { background: var(--success); color: #fff; border-color: var(--success); }
        .btn-warning { background: var(--card-bg); border: 1px solid var(--border-color); color: var(--warning); box-sizing: border-box;}
        .btn-warning:hover { background: var(--warning); color: #000; border-color: var(--warning); }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        table th, table td {
            text-align: left;
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        table th {
            color: #64748b;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 1px;
        }

        table form, table button {
            margin: 0;
            display: inline-block;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        .product-pills {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            justify-content: flex-start;
        }

        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #94a3b8;
        }

        /* Desktop specific styling for stok cell */
        table td.stok-cell {
            text-align: left;
        }
        @media (min-width: 769px) {
            table td.stok-cell .stok-number {
                display: block;
                margin-bottom: 6px;
            }
            table td.stok-cell .stok-buttons {
                display: flex !important;
                justify-content: flex-start;
            }
        }

        .form-control {
            width: 100%;
            background: var(--bg-color);
            border: 1px solid var(--border-color);
            color: var(--text-color);
            padding: 0.8rem;
            border-radius: 6px;
            font-family: inherit;
            box-sizing: border-box;
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-accent);
            box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.2);
        }

        .custom-tooltip {
            position: absolute;
            background: #ea580c;
            color: #fff;
            padding: 0.5rem 0.8rem;
            border-radius: 4px;
            font-size: 0.85rem;
            margin-top: 4px;
            left: 0;
            z-index: 50;
            opacity: 0;
            transform: translateY(-5px);
            transition: all 0.5s ease;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            pointer-events: none;
            font-weight: 500;
        }
        .custom-tooltip::before {
            content: "!";
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 16px;
            height: 16px;
            background: #fff;
            color: #ea580c;
            border-radius: 50%;
            font-weight: bold;
            margin-right: 6px;
            font-size: 0.7rem;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            color: #10b981;
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1.5rem;
            border: 1px solid rgba(16, 185, 129, 0.2);
            font-weight: 600;
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1.5rem;
            border: 1px solid rgba(239, 68, 68, 0.2);
            font-weight: 600;
        }

        .alert-dismissible {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 9999;
            min-width: 300px;
            text-align: center;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);
            transition: opacity 0.5s ease-out;
        }

        .stat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 1.5rem;
        }

        @media (max-width: 1024px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Mobile Overlay */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 1040;
        }
        .sidebar-overlay.active {
            display: block;
        }

        .mobile-only {
            display: none;
        }

        .val-wrap {
            display: contents; /* Biarkan perilaku default di desktop agar sejajar th */
        }

        @media (max-width: 768px) {
            .sidebar {
                position: fixed !important;
                left: -250px;
                top: 0;
                bottom: 0;
                height: 100vh;
                z-index: 1050;
                box-shadow: 4px 0 10px rgba(0,0,0,0.5);
                transform: none !important;
                display: flex !important;
                transition: left 0.3s ease;
            }
            
            .sidebar.mobile-open {
                left: 0;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .product-pills {
                justify-content: flex-end;
            }

            .val-wrap {
                display: flex;
                justify-content: flex-end;
                width: 100%;
            }
            .mobile-only {
                display: flex;
            }
            body {
                flex-direction: column;
                padding-bottom: 0; /* Remove bottom nav space */
            }
            .content {
                padding: 1.5rem 1rem;
                width: 100%;
                box-sizing: border-box;
            }
            .header {
                padding: 1rem 0;
                margin-bottom: 1.5rem;
                border-bottom: 1px solid var(--border-color);
            }
            .header h1 {
                font-size: 1.3rem;
                font-weight: 800;
                letter-spacing: -0.5px;
            }

            /* Hilangkan tampilan kotak double hanya untuk card yang berisi tabel */
            .card:has(table) {
                background: transparent !important;
                border: none !important;
                box-shadow: none !important;
                padding: 0 !important;
            }
            /* Tapi tetap beri background untuk kartu statistik di dashboard */
            .stat-grid .card, .stat-grid .card *, .filter-form {
                background: var(--card-bg) !important;
                border: 1px solid var(--border-color) !important;
                padding: 1.25rem !important;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;
                border-radius: 16px !important;
            }

            /* Modern List Card (Mobile Table Replacement) */
            table, thead, tbody, th, td, tr {
                display: block;
                width: 100%;
                box-sizing: border-box;
            }
            table thead {
                display: none;
            }
            table tr {
                background: var(--card-bg);
                border-radius: 16px;
                padding: 0.8rem 1rem;
                margin-bottom: 1rem;
                border: 1px solid var(--border-color);
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                position: relative;
            }
            .val-wrap > *:last-child {
                margin-right: 0 !important;
            }
            table td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0.5rem 0 !important;
                border-bottom: 1px solid rgba(255,255,255,0.05);
                gap: 12px;
            }

            .stack-on-mobile {
                flex-direction: column !important;
                align-items: flex-start !important;
            }
            .stack-on-mobile::before {
                margin-bottom: 8px;
            }
            .stack-on-mobile .val-wrap {
                justify-content: flex-start !important;
                text-align: left !important;
            }
            .stack-on-mobile .product-pills {
                justify-content: flex-start !important;
            }
            .stack-on-mobile .stock-action-wrap {
                align-items: flex-start !important;
            }
            /* Align table cell content to the right on mobile */
            table td > span, 
            table td > strong, 
            table td > div {
                text-align: right;
            }

            table td.stok-cell {
                flex-wrap: wrap;
            }
            .stok-cell .val-wrap {
                width: auto;
                flex: 1;
            }
            .stok-cell .stok-buttons {
                width: 100%;
                order: 3;
                display: grid !important;
                grid-template-columns: 1fr 1fr;
                gap: 8px;
                margin-top: 8px;
            }
            .stok-cell .stok-buttons a {
                text-align: center;
                padding: 10px !important;
                display: block;
                box-sizing: border-box;
            }

            table td:last-child {
                border-bottom: none;
            }

            /* Hide Aksi label and align buttons to the left as requested */
            table td[data-label="Aksi"]::before {
                display: none;
            }
            table td[data-label="Aksi"] {
                padding-top: 0.75rem !important;
                justify-content: flex-start;
                gap: 8px;
            }
            table td[data-label="Aksi"] .val-wrap {
                width: 100%;
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 8px;
            }
            table td[data-label="Aksi"] .val-wrap > a,
            table td[data-label="Aksi"] .val-wrap > form {
                width: 100%;
                margin: 0 !important;
                box-sizing: border-box;
                text-align: center;
            }
            table td[data-label="Aksi"] .val-wrap > form > button {
                width: 100%;
                box-sizing: border-box;
                text-align: center;
            }
            
            /* First Cell as Header (Produk / Info Utama) */
            table td:first-child {
                border-bottom: 1px solid var(--border-color);
                padding-bottom: 0.6rem !important;
                margin-bottom: 0.25rem;
                font-size: 1.05rem;
                font-weight: 700;
                justify-content: flex-start;
                text-align: left;
                gap: 12px;
            }
            table td:first-child::before {
                display: none;
            }
            table td:first-child > * {
                text-align: left;
            }

            table td::before {
                content: attr(data-label);
                font-weight: 600;
                color: #64748b;
                font-size: 0.7rem;
                text-transform: uppercase;
                letter-spacing: 0.8px;
                white-space: nowrap;
                flex-shrink: 0;
            }

            .stat-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
        }

        @media print {
            .sidebar, .btn, .header .btn-group, .filter-form { display: none !important; }
            .content { padding: 0 !important; margin: 0 !important; width: 100% !important; }
            .card { border: none !important; box-shadow: none !important; padding: 0 !important; background: transparent !important; color: #000 !important; }
            body { background: white !important; color: #000 !important; }
            table th { color: #000 !important; border-bottom: 2px solid #000 !important; }
            table td { border-bottom: 1px solid #eee !important; color: #000 !important; }
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
</head>
<body>

    <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleMobileSidebar()"></div>
    <div class="sidebar" id="sidebar">

        <div style="display: flex; align-items: center; justify-content: center; gap: 12px; margin-bottom: 2rem; overflow: hidden;">
            <img src="<?php echo e(asset('logo.jpg')); ?>" alt="L" style="width: 40px; min-width: 40px; height: auto; mix-blend-mode: screen; filter: grayscale(100%) contrast(3) brightness(0.9);">
            <span style="font-size: 1.2rem; font-weight: 800; letter-spacing: 2px; color: var(--text-color); white-space: nowrap;">KOPLINK</span>
        </div>
        
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="<?php echo e(request()->routeIs('admin.products.*') || request()->routeIs('admin.stock.form') ? 'active' : ''); ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
            <span>Produk</span>
        </a>
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="<?php echo e(request()->routeIs('admin.categories.*') ? 'active' : ''); ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
            <span>Kategori</span>
        </a>
        <a href="<?php echo e(route('admin.stock.history')); ?>" class="<?php echo e(request()->routeIs('admin.stock.history') ? 'active' : ''); ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20V10"></path><path d="M18 20V4"></path><path d="M6 20v-4"></path></svg>
            <span>Riwayat Stok</span>
        </a>
        <a href="<?php echo e(route('admin.reports.index')); ?>" class="<?php echo e(request()->routeIs('admin.reports.*') ? 'active' : ''); ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>
            <span>Laporan</span>
        </a>

        <form action="<?php echo e(route('logout')); ?>" method="POST" style="margin-top: auto;">
            <?php echo csrf_field(); ?>
            <button type="submit" style="background: transparent; border: 1px solid var(--border-color); color: #ffffff; padding: 0.8rem; cursor: pointer; font-weight: 700; width: 100%; border-radius: 8px; display: flex; align-items: center; justify-content: center; gap: 12px; transition: 0.3s;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                <span>Log Out</span>
            </button>
        </form>
    </div>

    <script>
        const sidebar = document.getElementById('sidebar');

        function toggleMobileSidebar() {
            const overlay = document.getElementById('sidebarOverlay');
            if (sidebar.classList.contains('mobile-open')) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('active');
            } else {
                sidebar.classList.add('mobile-open');
                overlay.classList.add('active');
            }
        }
    </script>

    <div class="content">
        <div class="header" style="display: flex; align-items: center; gap: 1rem;">
            <button class="mobile-only" onclick="toggleMobileSidebar()" style="background: transparent; border: none; border-radius: 6px; padding: 8px; color: var(--text-color); cursor: pointer;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            </button>
            <h1 style="flex: 1;"><?php echo $__env->yieldContent('title', 'Admin Panel'); ?></h1>
        </div>

        <?php if(session('success')): ?>
            <div class="alert-success alert-dismissible" role="alert">
                <span><?php echo e(session('success')); ?></span>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert-error alert-dismissible" role="alert">
                <span><?php echo e(session('error')); ?></span>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert-error alert-dismissible" role="alert">
                <ul style="margin: 0; padding-left: 20px; text-align: left; list-style-position: inside;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>



    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Auto fade out alerts after 1 second
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert-dismissible');
                alerts.forEach(function(alert) {
                    alert.style.opacity = '0';
                    setTimeout(() => {
                        alert.style.display = 'none';
                    }, 300);
                });
            }, 1000);

            // Custom HTML5 Validation Tooltip
            document.addEventListener('invalid', function(e) {
                e.preventDefault();
                const input = e.target;
                
                // Remove existing tooltip if any
                const existing = input.parentElement.querySelector('.custom-tooltip');
                if (existing) {
                    existing.remove();
                }

                if (getComputedStyle(input.parentElement).position === 'static') {
                    input.parentElement.style.position = 'relative';
                }

                const tooltip = document.createElement('div');
                tooltip.className = 'custom-tooltip';
                tooltip.innerText = "Harap isi kolom ini."; 
                
                input.parentElement.appendChild(tooltip);

                // Animate in
                requestAnimationFrame(() => {
                    tooltip.style.opacity = '1';
                    tooltip.style.transform = 'translateY(0)';
                });

                if (document.activeElement !== input) {
                    input.focus();
                }

                // Animate out after 1.5 seconds
                setTimeout(() => {
                    if(tooltip) {
                        tooltip.style.opacity = '0';
                        tooltip.style.transform = 'translateY(-5px)';
                        setTimeout(() => { if(tooltip.parentElement) tooltip.remove(); }, 500);
                    }
                }, 1500);
            }, true);

            // Event delegation to catch all submissions of forms with class 'delete-form'
            document.body.addEventListener('submit', function(e) {
                const form = e.target;
                if (form.classList.contains('delete-form')) {
                    e.preventDefault();
                    
                    Swal.fire({
                        title: 'Apakah Anda yakin?',
                        text: "Data yang dihapus tidak dapat dikembalikan!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#ef4444',
                        cancelButtonColor: '#262626',
                        confirmButtonText: 'Ya, Hapus!',
                        cancelButtonText: 'Batal',
                        background: '#111111',
                        color: '#ffffff',
                        iconColor: '#ef4444'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            form.submit();
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\xamp\htdocs\web transaksi koplink\resources\views/layouts/admin.blade.php ENDPATH**/ ?>