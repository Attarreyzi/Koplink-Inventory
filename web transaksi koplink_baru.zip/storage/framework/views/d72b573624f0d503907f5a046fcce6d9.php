<?php $__env->startSection('title', 'Riwayat Stok'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <table>
        <thead>
            <tr>
                <th style="width: 35%; text-align: left;">Produk</th>
                <th style="width: 20%; text-align: left;">Waktu</th>
                <th style="width: 25%; text-align: center;">Jumlah</th>
                <th style="width: 20%; text-align: left;">Catatan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td data-label="Produk">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <?php if($t->product && $t->product->image): ?>
                            <img src="<?php echo e(str_starts_with($t->product->image, 'products/') ? url('/img-view/' . $t->product->image) : asset($t->product->image)); ?>" alt="" style="width: 35px; height: 35px; object-fit: cover; border-radius: 6px; border: 1px solid rgba(255,255,255,0.1);">
                        <?php else: ?>
                            <div style="width: 35px; height: 35px; background: #222; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 0.5rem; color: #555;">No Img</div>
                        <?php endif; ?>
                        <span><?php echo e($t->product->name ?? 'Produk Terhapus'); ?></span>
                    </div>
                </td>
                <td data-label="Waktu"><div class="val-wrap"><span><?php echo e($t->created_at->format('d M Y H:i')); ?></span></div></td>
                <td data-label="Jumlah" style="text-align: center;">
                    <div class="val-wrap">
                        <strong style="font-size: 1.1rem; color: <?php echo e($t->type == 'in' ? 'var(--text-color)' : 'var(--secondary-accent)'); ?>;">
                            <?php echo e($t->type == 'in' ? '+' : '-'); ?><?php echo e($t->quantity); ?>

                        </strong>
                    </div>
                </td>
                <td data-label="Catatan">
                    <div class="val-wrap">
                        <span style="color: var(--secondary-accent);"><?php echo e($t->note ?: '-'); ?></span>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" style="text-align: center; color: var(--secondary-accent); padding: 2rem 0;">Belum ada riwayat pergerakan stok.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamp\htdocs\web transaksi koplink\resources\views/admin/stock/history.blade.php ENDPATH**/ ?>