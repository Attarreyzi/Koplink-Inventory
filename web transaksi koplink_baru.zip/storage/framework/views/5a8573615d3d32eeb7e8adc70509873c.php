<?php $__env->startSection('title', 'Stok ' . ucfirst($type) . ' - ' . $product->name); ?>

<?php $__env->startSection('content'); ?>
<div style="margin-bottom: 1.5rem; display: flex; justify-content: flex-end;">
    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn" style="background:#333333; color:#ffffff; border:none;">Kembali</a>
</div>

<div class="card" style="max-width: 500px;">
    
    <div style="margin-bottom: 1.5rem; padding: 1.5rem; background: var(--bg-color); border: 1px solid var(--border-color); border-radius: 12px; text-align: center;">
        <div style="color: var(--secondary-accent); font-size: 0.9rem; text-transform: uppercase; font-weight: 600; letter-spacing: 0.05em;">Stok Saat Ini</div>
        <div style="font-size: 3rem; font-weight: 800; color: var(--text-color); line-height: 1;"><?php echo e($product->stock); ?></div>
    </div>

    <?php if($errors->any()): ?>
        <div style="color: var(--danger); margin-bottom: 1rem; font-weight: 600;">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.stock.store', [$product->id, $type])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Jumlah (Quantity)</label>
            <input type="number" name="quantity" class="form-control" required min="1">
        </div>

        <div class="form-group">
            <label>Catatan</label>
            <input type="text" name="note" class="form-control" placeholder="Contoh: stok <?php echo e($type == 'in' ? 'masuk' : 'keluar'); ?>" required>
        </div>

        <button type="submit" class="btn" style="width: 100%; border: 1px solid var(--primary-accent); <?php echo e($type == 'out' ? 'background: #ffffff; color: #000000;' : ''); ?>">
            <?php echo e($type == 'in' ? 'Tambahkan Stok' : 'Kurangi Stok'); ?>

        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamp\htdocs\web transaksi koplink\resources\views/admin/stock/form.blade.php ENDPATH**/ ?>