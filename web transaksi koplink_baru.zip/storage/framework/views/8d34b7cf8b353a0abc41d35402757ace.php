<?php $__env->startSection('title', 'Manajemen Kategori'); ?>

<?php $__env->startSection('content'); ?>
<div style="margin-bottom: 1.5rem; display: flex; justify-content: flex-end;">
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn">Tambah Kategori</a>
</div>



<div class="card">
    <table>
        <thead>
            <tr>
                <th style="width: 20%; text-align: left;">Kategori</th>
                <th style="width: 50%; text-align: left;">Daftar Produk</th>
                <th style="width: 15%; text-align: center;">Jumlah Produk</th>
                <th style="text-align: center; width: 15%;">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td data-label="Kategori" style="vertical-align: middle;">
                        <strong><?php echo e($category->name); ?></strong>
                    </td>
                    <td data-label="Daftar Produk" class="stack-on-mobile" style="vertical-align: middle; padding: 1rem 0;">
                        <div class="val-wrap" style="width: 100%;">
                            <?php if($category->products->isEmpty()): ?>
                                <span style="color: #64748b; font-style: italic;">Tidak ada produk</span>
                            <?php else: ?>
                                <div class="product-pills">
                                    <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span style="display: inline-block; background: rgba(255, 255, 255, 0.05); color: var(--text-color); padding: 0.3rem 0.7rem; border-radius: 6px; font-size: 0.85rem; border: 1px solid var(--border-color); font-weight: 600;">
                                            <?php echo e($product->name); ?>

                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td data-label="Jumlah Produk" style="text-align: center; vertical-align: middle;">
                        <div class="val-wrap">
                            <span style="font-weight: 600;"><?php echo e($category->products_count); ?></span>
                        </div>
                    </td>
                    <td data-label="Aksi" style="text-align: center; vertical-align: middle;">
                        <div class="val-wrap" style="grid-template-columns: 1fr;">
                            <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST" class="delete-form" style="display: block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" style="padding: 0.6rem 1rem;">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamp\htdocs\web transaksi koplink\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>